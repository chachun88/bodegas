<?php sleep(2) ?>
<div class="list-group users-list-group">
    <a href="#" class="list-group-item animated fadeInDown bg-addition">
        <img src="img/14.jpg" alt="" class="img-circle"/>
        <i class="fa fa-circle pull-right text-success"></i>
        <h5 class="no-margin"><strong>Jenny Wilington</strong></h5>
        <small>just now</small>
    </a>
    <a href="#" class="list-group-item">
        <img src="img/3.jpg" alt="" class="img-circle"/>
        <i class="fa fa-circle pull-right text-success"></i>
        <h5 class="no-margin">Valdemar Landau</h5>
        <small class="text-muted">one hour ago</small>
    </a>
    <a href="#" class="list-group-item">
        <img src="img/1.jpg" alt="" class="img-circle"/>
        <i class="fa fa-circle pull-right text-danger"></i>
        <h5 class="no-margin">Maikel Basso</h5>
        <small class="text-muted">about 2 mins ago</small>
    </a>
    <a href="#" class="list-group-item">
        <img src="img/13.jpg" alt="" class="img-circle"/>
        <i class="fa fa-circle pull-right text-warning"></i>
        <h5 class="no-margin">Rick Teagan</h5>
        <small class="text-muted">3 hours ago</small>
    </a>
    <a href="#" class="list-group-item">
        <img src="img/2.jpg" alt="" class="img-circle"/>
        <i class="fa fa-circle pull-right text-info"></i>
        <h5 class="no-margin">Ianus Arendse</h5>
        <small class="text-muted">about 42 mins ago</small>
    </a>
</div>