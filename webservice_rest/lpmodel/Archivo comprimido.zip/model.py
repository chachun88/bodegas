#!/usr/bin/python
# -*- coding: UTF-8 -*-

import xml.etree.ElementTree as ET
import os

f = open ('bodegas.uml', 'r')
file_data = f.read().replace("uml:", "uml_").replace("xmi:", "xmi_") ## translate uml to common xml

root = ET.fromstring(file_data)

## find class name
def findClassName(identifier):
	for cls in root.findall('packagedElement'):
		if identifier == cls.get('xmi_id'):
			return cls.get('name')

	return ""


## getting all packagedElement
for cls in root.findall('packagedElement'):

	## class variables
	parent_class = "object"
	class_name = cls.get('name')
	attributes = []
	operations = []

	## getting parent class
	try:
		general_id = cls.find('generalization')
		
		if hasattr(general_id, "get"):
			parent_class = findClassName(general_id.get('general'))
	except Exception, e:
		raise

	## looping attributes
	for attr in cls.findall('ownedAttribute'):
		attributes.append({"name":attr.get("name"), "type":"String"}) # TODO : fix this value

	## lopping operations
	for op in cls.findall('ownedOperation'):

		operation = {"name":op.get("name"), "is_static":False, "return":"String", "parameters":[]} # TODO : fix this value

		#if hasattr(op, "isStatic"):
		operation["is_static"] = bool(op.get("isStatic"))

		## looping parameters
		for param in op.findall("ownedParameter"):
			if param.get("name") != "returnParameter":
				operation["parameters"].append({"name":param.get("name")})

		operations.append(operation)

	##debugging
	print "\n\n"
	print class_name
	print parent_class
	print attributes
	print operations